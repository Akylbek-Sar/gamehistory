
# Kazakh History Game

Интерактивная веб-игра на тему истории Казахстана.
## Установка
```bash
npm install
npm run dev
```

## Технологии:
- React + Next.js
- Tailwind CSS + shadcn/ui
- Framer Motion + use-sound
